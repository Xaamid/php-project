 Class=ca222
 Group Name Group_K
 Title= Student_Course_Wpork_Management_System

C1220578	Mohamed Farah Warsame

C1221062	Abdiweli Mohamud Mohamed

C1220555	Farah Abdikarim Sahal

C1220920	Abdiwahab Salad Hirat